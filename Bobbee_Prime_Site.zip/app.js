
function submit() {
    const apiKey = document.getElementById('apiKey').value;
    const password = document.getElementById('sitePassword').value;
    const query = document.getElementById('query').value;
    const responseBox = document.getElementById('response');

    if (password !== "2316$$$BjT") {
        responseBox.innerHTML = "<span style='color:red'>❌ Incorrect Password</span>";
        return;
    }

    if (!apiKey || !query) {
        responseBox.innerHTML = "<span style='color:red'>❌ API Key and Query required</span>";
        return;
    }

    responseBox.innerHTML = "⏳ Talking to your 1000 geniuses...";
    // Real OpenAI API call would go here
    setTimeout(() => {
        responseBox.innerHTML = "✅ (Mocked) Bobbee Prime Response: We see it all. We fix it all.";
    }, 1500);
}
