
# Bobbee Prime: Supreme AI
Your secure portal for legal, medical, creative, and forensic superintelligence.

- Upload evidence (.pdf, .doc, .txt)
- Input your OpenAI API Key
- Ask questions to your 1000-genius AI

## Setup
Upload the contents of this folder to GitHub, connect to Netlify, or open `index.html` locally in a browser.
